function calcularSalario() {
    var nivel = parseInt(document.getElementById("nivel").value);
    var qtdAula = parseInt(document.getElementById("qtdAula").value);

    var valorHoraAula;
    switch (nivel) {
        case 1:
            valorHoraAula = 12.00;
            break;
        case 2:
            valorHoraAula = 17.00;
            break;
        case 3:
            valorHoraAula = 25.00;
            break;
        default:
            alert("Selecione um nível válido.");
            return;
    }

    var salario = valorHoraAula * qtdAula * 4.5;

    var resultadoElemento = document.getElementById("resultado");
    resultadoElemento.innerHTML = "<p>Nível do Professor: " + nivel + "</p>" +
                                   "<p>Quantidade de Horas/Aula por Semana: " + qtdAula + "</p>" +
                                   "<p>Salário Mensal: R$ " + salario.toFixed(2) + "</p>";
}

function calcularNovoSalario() {
    var salarioAtual = parseFloat(document.getElementById("salario").value);
    var cargo = document.getElementById("cargo").value;
    
    var percentualAumento;
    switch (cargo) {
        case "101":
            percentualAumento = 0.10;
            break;
        case "102":
            percentualAumento = 0.20;
            break;
        case "103":
            percentualAumento = 0.30;
            break;
        default:
            percentualAumento = 0.40;
            break;
    }

    var aumento = salarioAtual * percentualAumento;
    var novoSalario = salarioAtual + aumento;
    var diferenca = aumento;
    
    var resultadoElemento = document.getElementById("resultado");
    resultadoElemento.innerHTML = "<p>Salário Antigo: R$ " + salarioAtual.toFixed(2) + "</p>" +
                                   "<p>Novo Salário: R$ " + novoSalario.toFixed(2) + "</p>" +
                                   "<p>Diferença: R$ " + diferenca.toFixed(2) + "</p>";
}
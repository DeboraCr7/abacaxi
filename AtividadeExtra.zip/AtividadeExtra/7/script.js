function calcularValor() {

    var produto = document.getElementById("produto").value;
    var quantidade = parseInt(document.getElementById("quantidade").value);

    var preco;
    switch (produto) {
        case "cachorroQuente":
            preco = 11.00;
            break;
        case "bauru":
            preco = 8.50;
            break;
        case "mistoQuente":
            preco = 8.00;
            break;
        case "hamburguer":
            preco = 9.00;
            break;
        case "cheeseburguer":
            preco = 10.00;
            break;
        case "refrigerante":
            preco = 4.50;
            break;
        default:
            alert("Produto inválido!");
            return;
    }

    var valorTotal = preco * quantidade;

    var resultadoElemento = document.getElementById("resultado");
    resultadoElemento.innerHTML = "<p>Produto: " + produto + "</p>" +
                                   "<p>Quantidade: " + quantidade + "</p>" +
                                   "<p>Valor Total: R$ " + valorTotal.toFixed(2) + "</p>";
}
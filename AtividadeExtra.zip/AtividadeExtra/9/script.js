function calcularValorFinal() {

    var preco = parseFloat(document.getElementById("preco").value);
    var condicao = document.getElementById("condicao").value;

    var valorFinal;
    switch (condicao) {
        case "a":
            valorFinal = preco * 0.9;
            break;
        case "b":
            valorFinal = preco * 0.85;
            break;
        case "c":
            valorFinal = preco;
            break;
        case "d":
            valorFinal = preco * 1.1;
            break;
        default:
            alert("Escolha uma condição de pagamento válida.");
            return;
    }

    var resultadoElemento = document.getElementById("resultado");
    resultadoElemento.innerHTML = "<p>Preço Normal: R$ " + preco.toFixed(2) + "</p>" +
                                   "<p>Valor Final a Pagar: R$ " + valorFinal.toFixed(2) + "</p>";
}
document.getElementById("verificarBtn").addEventListener("click", function() {

    var X = parseFloat(document.getElementById("ladoX").value);
    var Y = parseFloat(document.getElementById("ladoY").value);
    var Z = parseFloat(document.getElementById("ladoZ").value);
   
    if (X >= Y + Z || Y >= X + Z || Z >= X + Y) {
      document.getElementById("resultado").textContent = "Os valores não formam um triângulo.";
    } else if (X === Y && Y === Z) {
      document.getElementById("resultado").textContent = "Triângulo Equilátero";
    } else if (X === Y || X === Z || Y === Z) {
      document.getElementById("resultado").textContent = "Triângulo Isósceles";
    } else {
      document.getElementById("resultado").textContent = "Triângulo Escaleno";
    }
  });
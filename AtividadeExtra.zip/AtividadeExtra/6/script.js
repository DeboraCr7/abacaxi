function calcularCreditoEspecial() {
    var saldoMedio = parseFloat(document.getElementById("saldoMedio").value);

    var percentualCredito;
    if (saldoMedio >= 0 && saldoMedio <= 200) {
        percentualCredito = 0;
    } else if (saldoMedio <= 400) {
        percentualCredito = 0.20;
    } else if (saldoMedio <= 600) {
        percentualCredito = 0.30;
    } else {
        percentualCredito = 0.40;
    }

    var valorCredito = saldoMedio * percentualCredito;

    var resultadoElemento = document.getElementById("resultado");
    resultadoElemento.innerHTML = "<p>Saldo Médio: R$ " + saldoMedio.toFixed(2) + "</p>" +
                                   "<p>Valor do Crédito: R$ " + valorCredito.toFixed(2) + "</p>";
}function calcularValor() {

    var produto = document.getElementById("produto").value;
    var quantidade = parseInt(document.getElementById("quantidade").value);

    var preco;
    switch (produto) {
        case "cachorroQuente":
            preco = 11.00;
            break;
        case "bauru":
            preco = 8.50;
            break;
        case "mistoQuente":
            preco = 8.00;
            break;
        case "hamburguer":
            preco = 9.00;
            break;
        case "cheeseburguer":
            preco = 10.00;
            break;
        case "refrigerante":
            preco = 4.50;
            break;
        default:
            alert("Produto inválido!");
            return;
    }

    var valorTotal = preco * quantidade;

    var resultadoElemento = document.getElementById("resultado");
    resultadoElemento.innerHTML = "<p>Produto: " + produto + "</p>" +
                                   "<p>Quantidade: " + quantidade + "</p>" +
                                   "<p>Valor Total: R$ " + valorTotal.toFixed(2) + "</p>";
}
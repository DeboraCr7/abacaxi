document.getElementById("calcularBtn").addEventListener("click", function() {
    var valorReais = parseFloat(document.getElementById("valorReais").value);
    var valorInicial = valorReais; 
    
    var notas100 = 0, notas50 = 0, notas10 = 0, notas5 = 0, notas1 = 0;
    
    notas100 = Math.floor(valorReais / 100);
    valorReais %= 100;
    
    notas50 = Math.floor(valorReais / 50);
    valorReais %= 50;
    
    notas10 = Math.floor(valorReais / 10);
    valorReais %= 10;
    
    notas5 = Math.floor(valorReais / 5);
    valorReais %= 5;
    
    notas1 = Math.floor(valorReais / 1);
    
    document.getElementById("valorLido").textContent = "Valor lido: R$ " + valorInicial.toFixed(2);
    document.getElementById("notasResultado").textContent = `
      Notas de R$ 100: ${notas100}
      Notas de R$ 50: ${notas50}
      Notas de R$ 10: ${notas10}
      Notas de R$ 5: ${notas5}
      Notas de R$ 1: ${notas1}
    `;
  });
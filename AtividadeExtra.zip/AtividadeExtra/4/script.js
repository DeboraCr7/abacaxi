function calcularImposto() {

    var ano = parseInt(document.getElementById("ano").value);
    var valor = parseFloat(document.getElementById("valor").value);

    var taxa;
    if (ano < 1990) {
        taxa = 0.01;
    } else {
        taxa = 0.015;
    }

    var imposto = taxa * valor;

    var resultadoElemento = document.getElementById("resultado");
    resultadoElemento.textContent = "Imposto a ser pago: R$ " + imposto.toFixed(2);
}